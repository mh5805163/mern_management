'use client'

import { useMemo, useState } from 'react'
import {
  Bell,
  CalendarDays,
  ChevronDown,
  ChevronRight,
  CircleHelp,
  Clock3,
  Download,
  Grid2X2,
  LayoutDashboard,
  Menu,
  MessageSquare,
  MoreHorizontal,
  Plus,
  Search,
  Settings,
  Sparkles,
  Ticket,
  Users,
  X,
} from 'lucide-react'

const events = [
  { name: 'Future Forward 2025', type: 'Technology', date: 'Oct 14–16, 2025', venue: 'Pier 48, San Francisco', attendees: '8,420', status: 'Live', color: 'coral' },
  { name: 'The Green Summit', type: 'Sustainability', date: 'Nov 04–05, 2025', venue: 'Stockholm Waterfront', attendees: '2,840', status: 'Published', color: 'mint' },
  { name: 'Design Systems Week', type: 'Design', date: 'Dec 02–04, 2025', venue: 'Online + London', attendees: '5,120', status: 'Draft', color: 'lilac' },
]

const navItems = [
  { label: 'Overview', icon: LayoutDashboard },
  { label: 'Events', icon: CalendarDays },
  { label: 'Exhibitors', icon: Users },
  { label: 'Floor plans', icon: Grid2X2 },
  { label: 'Schedule', icon: Clock3 },
  { label: 'Messages', icon: MessageSquare, count: 4 },
]

function StatCard({ label, value, delta, detail, icon: Icon, tone }: { label: string; value: string; delta: string; detail: string; icon: typeof Users; tone: string }) {
  return (
    <article className="stat-card">
      <div className="stat-topline"><span>{label}</span><span className={`icon-box ${tone}`}><Icon size={17} /></span></div>
      <div className="stat-value-row"><strong>{value}</strong><span className="positive">{delta}</span></div>
      <p>{detail}</p>
    </article>
  )
}

function EventRow({ event }: { event: typeof events[number] }) {
  return (
    <div className="event-row">
      <div className={`event-thumb ${event.color}`}><Sparkles size={20} /><span>{event.type}</span></div>
      <div className="event-main"><strong>{event.name}</strong><span>{event.date} · {event.venue}</span></div>
      <div className="event-attendees"><Users size={15} /> {event.attendees}</div>
      <span className={`status ${event.status.toLowerCase()}`}>{event.status}</span>
      <button className="icon-button" aria-label={`More actions for ${event.name}`}><MoreHorizontal size={18} /></button>
    </div>
  )
}

function App() {
  const [active, setActive] = useState('Overview')
  const [query, setQuery] = useState('')
  const [showNotifications, setShowNotifications] = useState(false)
  const [showCreate, setShowCreate] = useState(false)
  const [toast, setToast] = useState('')
  const [mobileOpen, setMobileOpen] = useState(false)

  const filteredEvents = useMemo(() => events.filter((event) => event.name.toLowerCase().includes(query.toLowerCase())), [query])

  function announce(message: string) {
    setToast(message)
    window.setTimeout(() => setToast(''), 2800)
  }

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
        <div className="brand"><span className="brand-mark"><span /></span><span>Event<span>Sphere</span></span></div>
        <div className="workspace-switcher"><div className="workspace-avatar">FF</div><div><strong>Future Forward</strong><span>Organization</span></div><ChevronDown size={15} /></div>
        <nav className="nav-list" aria-label="Primary navigation">
          <p className="nav-label">Workspace</p>
          {navItems.map(({ label, icon: Icon, count }) => <button key={label} onClick={() => { setActive(label); setMobileOpen(false) }} className={`nav-item ${active === label ? 'active' : ''}`}><Icon size={18} /><span>{label}</span>{count && <b>{count}</b>}</button>)}
          <p className="nav-label nav-label-spaced">Manage</p>
          <button className="nav-item"><Ticket size={18} /><span>Registrations</span></button>
          <button className="nav-item"><Download size={18} /><span>Reports</span></button>
        </nav>
        <div className="sidebar-bottom"><button className="nav-item"><Settings size={18} /><span>Settings</span></button><button className="nav-item"><CircleHelp size={18} /><span>Help center</span></button><div className="profile"><div className="profile-avatar">AM</div><div><strong>Alex Morgan</strong><span>Administrator</span></div><MoreHorizontal size={17} /></div></div>
      </aside>

      <main className="main-content">
        <header className="topbar"><button className="mobile-menu" aria-label="Open navigation" onClick={() => setMobileOpen(true)}><Menu size={20} /></button><div className="breadcrumbs"><span>Workspace</span><ChevronRight size={15} /><strong>{active}</strong></div><div className="topbar-actions"><div className="search-wrap"><Search size={17} /><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search anything" aria-label="Search anything" /><kbd>⌘ K</kbd></div><button className="top-icon" onClick={() => setShowNotifications(!showNotifications)} aria-label="Show notifications"><Bell size={19} /><i /></button><div className="top-avatar">AM</div></div>{showNotifications && <div className="notification-pop"><strong>Notifications</strong><p><span className="dot coral-dot" />Future Forward has 142 new registrations.</p><p><span className="dot mint-dot" />Booth A-14 is ready for review.</p><button onClick={() => setShowNotifications(false)}>Mark all as read</button></div>}</header>

        <div className="page-content">
          <div className="page-heading"><div><p className="eyebrow">Tuesday, October 14, 2025</p><h1>Good morning, Alex <span>✦</span></h1><p className="subheading">Here&apos;s what&apos;s happening across your events.</p></div><div className="heading-actions"><button className="secondary-button" onClick={() => announce('Report exported successfully')}><Download size={17} /> Export report</button><button className="primary-button" onClick={() => setShowCreate(true)}><Plus size={17} /> Create event</button></div></div>

          <section className="stats-grid"><StatCard label="Total registrations" value="18,240" delta="+18.2%" detail="vs. last month" icon={Users} tone="coral-tone" /><StatCard label="Active exhibitors" value="284" delta="+12.4%" detail="across 3 events" icon={Grid2X2} tone="mint-tone" /><StatCard label="Booth occupancy" value="86.8%" delta="+4.6%" detail="12 booths remaining" icon={Ticket} tone="lilac-tone" /><StatCard label="Engagement rate" value="72.4%" delta="+8.1%" detail="average event score" icon={Sparkles} tone="blue-tone" /></section>

          <section className="dashboard-grid"><article className="panel chart-panel"><div className="panel-heading"><div><h2>Registration overview</h2><p>Attendee growth across all active events</p></div><button className="filter-button">Last 30 days <ChevronDown size={15} /></button></div><div className="chart-legend"><span><i className="legend coral-bg" />Registrations</span><span><i className="legend gray-bg" />Check-ins</span></div><div className="chart"><div className="y-axis"><span>2,000</span><span>1,500</span><span>1,000</span><span>500</span><span>0</span></div><div className="chart-area"><div className="grid-lines"><i /><i /><i /><i /><i /></div><svg viewBox="0 0 680 220" preserveAspectRatio="none" aria-label="Registration trend chart"><defs><linearGradient id="fill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stopColor="#ff735f" stopOpacity=".25" /><stop offset="100%" stopColor="#ff735f" stopOpacity="0" /></linearGradient></defs><path d="M0 178 C35 167 55 176 82 150 S132 134 158 148 S202 142 232 112 S275 94 300 116 S344 95 370 105 S410 75 445 83 S478 67 504 78 S535 54 560 60 S610 30 680 20 L680 220 L0 220 Z" fill="url(#fill)" /><path d="M0 178 C35 167 55 176 82 150 S132 134 158 148 S202 142 232 112 S275 94 300 116 S344 95 370 105 S410 75 445 83 S478 67 504 78 S535 54 560 60 S610 30 680 20" fill="none" stroke="#ff735f" strokeWidth="3" strokeLinecap="round" /></svg><div className="x-axis"><span>Sep 15</span><span>Sep 20</span><span>Sep 25</span><span>Sep 30</span><span>Oct 05</span><span>Oct 10</span><span>Oct 14</span></div></div></div></article><article className="panel schedule-panel"><div className="panel-heading"><div><h2>Up next</h2><p>Your schedule for today</p></div><button className="text-button" onClick={() => setActive('Schedule')}>View schedule <ChevronRight size={15} /></button></div><div className="schedule-date"><strong>OCT <b>14</b></strong><span>Tuesday</span></div><div className="timeline"><div className="timeline-item"><span>09:30</span><div><strong>Opening keynote</strong><small>Auditorium · Future Forward</small></div></div><div className="timeline-item current"><span>11:00</span><div><strong>Exhibitor walkthrough</strong><small>Hall B · Floor plan review</small></div><b>Now</b></div><div className="timeline-item"><span>13:30</span><div><strong>Partner lunch</strong><small>Terrace room · Invite only</small></div></div></div></article></section>

          <section className="panel events-panel"><div className="panel-heading"><div><h2>Your events</h2><p>Manage and monitor your upcoming experiences</p></div><button className="text-button" onClick={() => setActive('Events')}>View all events <ChevronRight size={15} /></button></div><div className="event-table-head"><span>Event</span><span>Attendees</span><span>Status</span><span /></div>{filteredEvents.map((event) => <EventRow key={event.name} event={event} />)}{filteredEvents.length === 0 && <div className="empty-state">No events match “{query}”.</div>}</section>
          <footer className="footer"><span>EventSphere <b>·</b> Built for better events</span><span>Need help? <button onClick={() => announce('Support request started')}>Contact support</button></span></footer>
        </div>
      </main>

      {showCreate && <div className="modal-backdrop" role="presentation" onClick={() => setShowCreate(false)}><div className="modal" role="dialog" aria-modal="true" aria-labelledby="create-title" onClick={(e) => e.stopPropagation()}><div className="modal-header"><div><p className="eyebrow">New workspace item</p><h2 id="create-title">Create an event</h2></div><button className="icon-button" onClick={() => setShowCreate(false)} aria-label="Close dialog"><X size={19} /></button></div><label>Event name<input placeholder="e.g. Future Forward 2026" autoFocus /></label><label>Event type<select defaultValue="Technology"><option>Technology</option><option>Design</option><option>Sustainability</option><option>Conference</option></select></label><div className="modal-actions"><button className="secondary-button" onClick={() => setShowCreate(false)}>Cancel</button><button className="primary-button" onClick={() => { setShowCreate(false); announce('Draft event created') }}>Create draft</button></div></div></div>}
      {toast && <div className="toast" role="status"><span>✓</span>{toast}</div>}
    </div>
  )
}

export default function Page() { return <App /> }
