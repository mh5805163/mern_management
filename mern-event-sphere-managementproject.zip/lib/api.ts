export type EventRecord = { _id: string; name: string; type: string; date: string; venue: string; attendeeCount: number; status: 'Draft' | 'Published' | 'Live' }

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:4000/api'

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(`${API_URL}${path}`, { ...init, headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) } })
  const payload = await response.json()
  if (!response.ok) throw new Error(payload.error ?? 'Request failed')
  return payload.data as T
}

export const eventsApi = {
  list: () => request<EventRecord[]>('/events'),
  create: (event: Pick<EventRecord, 'name' | 'type' | 'date' | 'venue'>, token: string) => request<EventRecord>('/events', { method: 'POST', body: JSON.stringify(event), headers: { Authorization: `Bearer ${token}` } }),
}
